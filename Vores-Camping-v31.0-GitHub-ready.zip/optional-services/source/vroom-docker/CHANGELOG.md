# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [Unreleased]

[Vroom Changelog Unreleased](https://github.com/VROOM-Project/vroom/blob/master/CHANGELOG.md#unreleased)

[Vroom-express Changelog Unreleased](https://github.com/VROOM-Project/vroom-express/blob/master/CHANGELOG.md#unreleased)

## [v1.15.0](https://github.com/VROOM-Project/vroom/releases/tag/v1.15.0) - 2026-03-17

[Vroom Changelog v1.15.0](https://github.com/VROOM-Project/vroom/blob/master/CHANGELOG.md#v1150---2026-03-12)

[Vroom-express Changelog v0.12.0](https://github.com/VROOM-Project/vroom-express/blob/master/CHANGELOG.md#v0120---2023-11-16)

## [v1.15.0-rc.2](https://github.com/VROOM-Project/vroom/releases/tag/v1.15.0-rc.2) - 2026-01-26

[Vroom Changelog Unreleased](https://github.com/VROOM-Project/vroom/blob/master/CHANGELOG.md#unreleased)

[Vroom-express Changelog v0.12.0](https://github.com/VROOM-Project/vroom-express/blob/master/CHANGELOG.md#v0120---2023-11-16)

## [v1.15.0-rc.1](https://github.com/VROOM-Project/vroom/releases/tag/v1.15.0-rc.1) - 2025-12-04

[Vroom Changelog Unreleased](https://github.com/VROOM-Project/vroom/blob/master/CHANGELOG.md#unreleased)

[Vroom-express Changelog v0.12.0](https://github.com/VROOM-Project/vroom-express/blob/master/CHANGELOG.md#v0120---2023-11-16)

## [v1.14.0](https://github.com/VROOM-Project/vroom/releases/tag/v1.14.0) - 2024-01-23

[Vroom Changelog v1.14.0](https://github.com/VROOM-Project/vroom/blob/v1.14.0/CHANGELOG.md#v1140---2024-01-16)

[Vroom-express Changelog v0.12.0](https://github.com/VROOM-Project/vroom-express/blob/master/CHANGELOG.md#v0120---2023-11-16)

## [v1.14.0-rc.2](https://github.com/VROOM-Project/vroom/releases/tag/v1.14.0-rc.2) - 2023-11-16

[Vroom Changelog Unreleased](https://github.com/VROOM-Project/vroom/blob/master/CHANGELOG.md#unreleased)

[Vroom-express Changelog v0.12.0](https://github.com/VROOM-Project/vroom-express/blob/master/CHANGELOG.md#v0120---2023-11-16)

## [v1.14.0-rc.1](https://github.com/VROOM-Project/vroom/releases/tag/v1.14.0-rc.1) - 2023-11-15

[Vroom Changelog Unreleased](https://github.com/VROOM-Project/vroom/blob/master/CHANGELOG.md#unreleased)

[Vroom-express Changelog v0.11.0](https://github.com/VROOM-Project/vroom-express/blob/master/CHANGELOG.md#v0110---2022-06-11)

## [v1.13.0](https://github.com/VROOM-Project/vroom/blob/master/CHANGELOG.md#v1130---2023-01-31) - 2023-01-31

[Vroom Changelog v1.13.0](https://github.com/VROOM-Project/vroom/blob/master/CHANGELOG.md#v1130---2023-01-31)

[Vroom-express Changelog v0.11.0](https://github.com/VROOM-Project/vroom-express/blob/master/CHANGELOG.md#v0110---2022-06-11)

## [v1.12.2](https://github.com/VROOM-Project/vroom/blob/master/CHANGELOG.md#v1120---2022-05-31) - 2022-08-10

[Vroom Changelog v1.12.0](https://github.com/VROOM-Project/vroom/blob/master/CHANGELOG.md#v1120---2022-05-31)

[Vroom-express Changelog v0.11.0](https://github.com/VROOM-Project/vroom-express/blob/master/CHANGELOG.md#v0110---2022-06-11)

### Fixed

- introduced a regression in v1.12.1 where the runner image ran buster while the vroom was being done in bullseye [#61](https://github.com/VROOM-Project/vroom-docker/issues/61)

## [v1.12.1](https://github.com/VROOM-Project/vroom/blob/master/CHANGELOG.md#v1120---2022-05-31) - 2022-08-10

[Vroom Changelog v1.12.0](https://github.com/VROOM-Project/vroom/blob/master/CHANGELOG.md#v1120---2022-05-31)

[Vroom-express Changelog v0.11.0](https://github.com/VROOM-Project/vroom-express/blob/master/CHANGELOG.md#v0110---2022-06-11)

### Removed

- `docker-compose.yml` to narrow down this repo's responsibilities [#56](https://github.com/VROOM-Project/vroom-docker/issues/56)

### Changed

- `exec` the HTTP server in `docker-entrypoint.sh` to prevent sub-shelling [#58](https://github.com/VROOM-Project/vroom-docker/issues/58)

## [v1.12.0](https://github.com/VROOM-Project/vroom/blob/master/CHANGELOG.md#v1120---2022-05-31)

[Vroom Changelog v1.12.0](https://github.com/VROOM-Project/vroom/blob/master/CHANGELOG.md#v1120---2022-05-31)

[Vroom-express Changelog v0.11.0](https://github.com/VROOM-Project/vroom-express/blob/master/CHANGELOG.md#v0110---2022-06-11)

### Added

- Build arm64 image [#53](https://github.com/VROOM-Project/vroom-docker/pull/53)


## [v1.11.0](https://github.com/VROOM-Project/vroom/blob/master/CHANGELOG.md#v1110---2021-11-19) - 2021-11-20

[Vroom Changelog v1.11.0](https://github.com/VROOM-Project/vroom/blob/master/CHANGELOG.md#v1110---2021-11-19)

[Vroom-express Changelog v0.10.0](https://github.com/VROOM-Project/vroom-express/blob/master/CHANGELOG.md#v0100---2021-11-19)

### Changed

- Migrate image building process to Github Actions and implement tests [#37](https://github.com/VROOM-Project/vroom-docker/issues/37)


## [v1.10.0](https://github.com/VROOM-Project/vroom/blob/master/CHANGELOG.md#v1100---2021-05-06) - 2021-05-06

[Vroom Changelog v1.10.0](https://github.com/VROOM-Project/vroom/blob/master/CHANGELOG.md#v1100---2021-05-06)

[Vroom-express Changelog v0.9.0](https://github.com/VROOM-Project/vroom-express/blob/master/CHANGELOG.md#v090---2021-05-06)

### Added

- Valhalla description in _example_ `docker-compose.yml` and docs


## [v1.9.0](https://github.com/VROOM-Project/vroom-docker/releases/tag/v1.9.0) - 2021-03-04

[Vroom Changelog v1.9.0](https://github.com/VROOM-Project/vroom/blob/master/CHANGELOG.md#v190---2021-03-04)

[Vroom-express Changelog v0.8.0](https://github.com/VROOM-Project/vroom-express/blob/master/CHANGELOG.md#v080---2021-03-04)

### Fixed

- PBF file needs to be set by user in ORS instance ([#22](https://github.com/VROOM-Project/vroom-docker/issues/22))
- updated a deprecated java option for ORS ([#22](https://github.com/VROOM-Project/vroom-docker/issues/22))
- OSRM docker image had the wrong name (#23)

## [v1.8.0](https://github.com/VROOM-Project/vroom-docker/releases/tag/v1.8.0) - 2020-09-30

[Vroom Changelog v1.8.0](https://github.com/VROOM-Project/vroom/blob/master/CHANGELOG.md#v180---2020-09-29)

## [v1.7.0](https://github.com/VROOM-Project/vroom-docker/releases/tag/v1.7.0) - 2020-07-09

[Vroom Changelog v1.7.0](https://github.com/VROOM-Project/vroom/blob/master/CHANGELOG.md#v170---2020-07-08)

### Added

- License file to make it clear the project is under BSD-2-Clause ([#13](https://github.com/VROOM-Project/vroom-docker/issues/13))

### Changed

- `docker-compose` ORS setup to use `latest` image until new ORS release, 2020.05.26
- Support for VROOM release 1.7.0 and vroom-express release 0.7.0

## [v1.6.0](https://github.com/VROOM-Project/vroom-docker/releases/tag/v1.6.0) - 2020-05-03

First release.
