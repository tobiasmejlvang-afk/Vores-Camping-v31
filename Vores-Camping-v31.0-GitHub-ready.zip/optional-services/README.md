# Valgfrie geotjenester til Vores Camping v31.0

Denne mappe indeholder de uploadede serverprojekter. De er **valgfri backends** og er bevidst placeret uden for `/docs`, så den almindelige GitHub Pages-version stadig er enkel og virker som statisk PWA.

## Hvad appen forventer

| Tjeneste | Felt i appen | Forventet URL-form |
|---|---|---|
| OpenRouteService | Routing / Isochrones | Base-URL, fx `https://din-server/.../openrouteservice` |
| Pelias | Geocoding | Base-URL, der har `/autocomplete`, `/search` og `/reverse` |
| OpenPOIService | POI | Direkte POI-endpoint, fx `https://din-server/pois` |
| OpenElevationService | Elevation | Base-URL, fx `https://din-server/elevation`, så `/point` og `/line` findes under den |
| VROOM | Optimering | Direkte endpoint, der modtager VROOM POST-body |

Standardværdierne i appen er HeiGIT-endpoints. Når du ændrer et endpoint, betragtes det som selvhostet, og appen kræver ikke automatisk ORS-nøglen til det endpoint.

## Krav ved GitHub Pages

Egne tjenester skal typisk:

1. køre på en separat maskine/server – ikke i GitHub Pages;
2. være tilgængelige over HTTPS;
3. tillade CORS fra din GitHub Pages-origin;
4. have de nødvendige geografiske data importeret;
5. være dimensioneret til de requests du tillader.

## Kilder i pakken

- `source/openpoiservice/` – OpenPOIService-kilde.
- `source/openelevationservice/` – OpenElevationService-kilde.
- `source/vroom-docker/` – VROOM Docker-kilde; kræver en routing engine/backend.
- `source/pelias-docker/` – Pelias Docker-kilde; kræver Pelias-projekt/dataimport og konfiguration.

## Hvorfor der ikke er ét magisk docker-compose

De fire projekter har forskellige datakrav. Pelias skal have geocoder-data, OpenPOIService skal have POI-data/database, OpenElevationService skal have højdedata, og VROOM skal kunne tale med en kompatibel routing-engine. Et “start alt”-compose uden disse data ville se flot ud og virke omtrent lige så godt som en campingvogn uden hjul.

Derfor følger de originale kilder med som reference/udgangspunkt, mens v31.0-appen kan kobles på de færdige HTTPS-endpoints, når de er sat korrekt op.
